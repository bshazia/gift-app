import React from 'react';

import './Footer.css';
import logo from '../assets/images/logo.png';

const Footer = () => ( <
    footer className = "footer" >

    <
    a href = "https://igiftu.com/" > i - giftu.com < /a>   < /
    footer >
);
export default Footer;